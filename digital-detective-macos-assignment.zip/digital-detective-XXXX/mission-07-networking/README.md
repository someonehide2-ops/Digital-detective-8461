# Mission 7 — How computers communicate

## 1. Task / objective
Explain basic network types and concepts, observe network lookup and connectivity information, and describe what happens when a website opens.

## 2. Work completed
### Task 7.1 — Network concepts

| Concept | Explanation | Example |
|---|---|---|
| LAN | A network covering a small local area. | Home or computer lab network |
| MAN | A network covering a city or large campus area. | City-wide institutional network |
| WAN | A network covering large geographical areas. | The Internet |
| DNS | Translates a domain name into an IP address. | Resolving `example.com` |
| Router | Connects networks and forwards data between them. | Home Wi-Fi router |
| Protocol | A set of rules devices follow to communicate. | HTTP, HTTPS, TCP, IP |
| Packet switching | Data is split into packets that travel across networks. | Web data sent in IP packets |
| Client-server | A client requests a service and a server provides it. | Browser requesting a web page |

### Task 7.2 — Observe network information

Run the following in Terminal:

```bash
ping -c 4 example.com
nslookup example.com
```

A connectivity test helps check whether a host can be reached and provides response-time information. A DNS lookup displays DNS records such as the IP address associated with a domain name. DNS helps the browser find the network address for a website name.

[FILL IN: Record whether the ping test succeeded or failed and summarise the DNS lookup. Do not publish your own IP address, Wi-Fi name or other identifying network details. The domain's public address may be recorded if your instructor permits.]

### Task 7.3 — What happens when you open a website?

1. The user enters a website address in a browser. The browser acts as a client.
2. The client needs the server's network address, so it asks DNS to resolve the domain name.
3. DNS returns an IP address for the domain.
4. The computer sends network packets through its local network and router toward the destination.
5. The client and server communicate using protocols such as TCP/IP and HTTPS.
6. The server processes the request and sends a response, such as HTML, stylesheets, scripts and images.
7. The browser interprets the response and displays the website to the user.

## 3. Commands / tools used
`ping -c 4 example.com` sends four connectivity test packets; `nslookup example.com` queries DNS for the domain's records. Terminal is used to run both commands.

## 4. My understanding
A network connects devices so they can exchange data. LAN, MAN and WAN describe network coverage areas. DNS maps names to network addresses. Routers forward packets between networks. Protocols define how devices communicate, and client-server describes a common request-and-response model.

## 5. Difficulties faced
[FILL IN: Describe any errors, confusing steps or unexpected results. If none, write "No major difficulties".]

## 6. How I resolved them
[FILL IN: Explain the steps or help used to resolve each difficulty. If none, write "Not applicable".]

## 7. Evidence / files
- `[ADD A SHORT, REDACTED SUMMARY OF YOUR PING RESULT]`
- `[ADD A REDACTED SUMMARY OF YOUR NSLOOKUP RESULT]`

## 8. Commit details
- Commit message: `[FILL IN after creating the commit]`
- Pushed to GitHub: `[YES / NO — verify on GitHub]`
- Commit URL or short hash: `[FILL IN]`
