# Mission 8 — Final report and submission

## 1. Task / objective
Review the complete repository, make the root README useful to a visitor, verify all mission commits and submit the repository link.

## 2. Work completed
### Final repository review

Use this checklist after completing the practical work:

- [ ] All mission folders 00–08 are present.
- [ ] Every mission folder contains its own README.
- [ ] Mission 4 contains `hello.py` and the program runs.
- [ ] Mission 5 contains `number_converter.py` and it runs with at least three positive test values.
- [ ] All mission READMEs describe the task, work, commands/tools, understanding, difficulties, resolution, evidence and commit details.
- [ ] Each mission has at least one dedicated meaningful commit.
- [ ] All required commits are pushed and visible on GitHub.
- [ ] Git commit history, the `update-about` branch and Pull Request activity are visible.
- [ ] Network concepts and privacy-safe observations are documented.
- [ ] Root README contains the project introduction, mission links, topics, converter instructions and learning summary.
- [ ] Personal information has been removed from screenshots and outputs.
- [ ] Final changes are committed and pushed.

### Mission status

| Mission | Status | Commit hash / evidence |
|---|---|---|
| 0 — Setup | `[NOT STARTED / IN PROGRESS / COMPLETE]` | `[FILL IN]` |
| 1 — Computer basics | `[FILL IN]` | `[FILL IN]` |
| 2 — Terminal | `[FILL IN]` | `[FILL IN]` |
| 3 — Operating system | `[FILL IN]` | `[FILL IN]` |
| 4 — Programs | `[FILL IN]` | `[FILL IN]` |
| 5 — Numbers and data | `[FILL IN]` | `[FILL IN]` |
| 6 — Git and GitHub | `[FILL IN]` | `[FILL IN]` |
| 7 — Networking | `[FILL IN]` | `[FILL IN]` |
| 8 — Final report | `[FILL IN]` | `[FILL IN]` |

### Submission details

- Public GitHub repository URL: `[FILL IN]`
- Repository visibility verified as public: `[YES / NO]`
- Instructor's Google Form submitted: `[YES / NO — complete this yourself]`
- Submission date: `[FILL IN]`
- Final difficulty or correction: `[FILL IN]`

Do not claim that the repository was submitted until you have submitted its URL through the form shared by your instructor.

## 3. Commands / tools used
GitHub website to verify repository files, branches, Pull Request and commit history; `git status` and `git log --oneline` to inspect the local repository.

## 4. My understanding
A final review checks both the quality of the written work and the evidence that practical tasks were completed. A public repository should be understandable to a visitor, contain no private information and show separate commits for each mission.

## 5. Difficulties faced
[FILL IN: Describe any errors, confusing steps or unexpected results. If none, write "No major difficulties".]

## 6. How I resolved them
[FILL IN: Explain the steps or help used to resolve each difficulty. If none, write "Not applicable".]

## 7. Evidence / files
- `[ADD FINAL REPOSITORY URL]`
- `[ADD PRIVACY-SAFE SCREENSHOT OF REPOSITORY STRUCTURE AND COMMIT HISTORY]`
- `[ADD PULL REQUEST URL / STATUS]`

## 8. Commit details
- Commit message: `[FILL IN after creating the commit]`
- Pushed to GitHub: `[YES / NO — verify on GitHub]`
- Commit URL or short hash: `[FILL IN]`
