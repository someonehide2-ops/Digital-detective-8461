# Terminal practice area

Create and edit practice files only in this folder during Mission 2. You can keep this README or remove it after completing the exercise.
