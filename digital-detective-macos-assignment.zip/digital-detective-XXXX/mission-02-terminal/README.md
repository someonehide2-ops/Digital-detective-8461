# Mission 2 — Become comfortable with the Terminal

## 1. Task / objective
Use the command-line interface to inspect folders, create and manage practice files, understand flags and pipes, and explain package managers.

## 2. Work completed
### Task 2.1 — Basic Terminal command reference

Run commands from inside your assignment repository. For file creation, copying, moving and deletion practice, stay inside `terminal-practice/`.

| Operation | macOS command | What it does |
|---|---|---|
| Current-directory display | `pwd` | Prints the full path of the current folder. |
| Directory listing | `ls` | Lists visible files and folders. |
| Detailed listing | `ls -l` | Shows details such as permissions, owner, size and date. |
| Change to parent | `cd ..` | Moves one directory level up. |
| Create directory | `mkdir practice` | Creates a folder named practice. |
| Create empty file | `touch practice/notes.txt` | Creates an empty file if it does not exist. |
| Copy file | `cp practice/notes.txt practice/notes-copy.txt` | Creates a copy with another name. |
| Move / rename file | `mv practice/notes-copy.txt practice/backup.txt` | Moves or renames the file. |
| Display file contents | `cat practice/notes.txt` | Prints the file contents. |

[FILL IN: Record what you actually observed for each command. Do not paste private paths or usernames.]

### Task 2.2 — Safe file changes

Use only the `terminal-practice` folder inside this repository.

```bash
mkdir -p terminal-practice
cd terminal-practice
touch diary.txt
echo "First line" > diary.txt
echo "Second line" >> diary.txt
cat diary.txt
cp diary.txt diary-backup.txt
mv diary-backup.txt diary-copy.txt
```

- `>` replaces a file's contents (or creates the file).
- `>>` appends text to the end without removing existing lines.
- Copying creates another file while leaving the original in place.
- Moving relocates a file; using `mv` with a new name in the same folder renames it.
- `pwd` tells me where commands will operate.
- `ls` helps me see the contents of the current folder before working.

### Task 2.3 — Flags and pipes

| Command | Meaning |
|---|---|
| `ls` | Basic directory listing |
| `ls -l` | Detailed listing |
| `ls -la` | Detailed listing including hidden entries |
| `ls -lah` | Detailed listing, hidden entries and human-readable sizes |
| `ls -lah | head -n 5` | Sends the listing to `head`, which displays the first five lines |

A flag changes how a command behaves. The pipe symbol `|` sends the output of the command on its left as input to the command on its right. Here, `ls -lah` creates the listing and `head -n 5` limits what is displayed.

### Task 2.4 — Package managers

Homebrew is a package manager commonly used on macOS. If it is already installed, check it without installing or removing anything:

```bash
brew --version
brew list
```

If `brew` is not found, do not install it for this assignment; record that it is not installed. A package manager helps users install, update and remove software in a more organised way and can manage software dependencies.

[FILL IN: State whether Homebrew was already installed and record only privacy-safe observations.]

## 3. Commands / tools used
Commands: `pwd`, `ls`, `cd`, `mkdir`, `touch`, `cp`, `mv`, `cat`, `echo`, `head`, `brew --version`, `brew list`. The `-l`, `-a` and `-h` options modify the listing. The `|` pipe connects command output to another command.

## 4. My understanding
The Terminal accepts text commands. A directory is a folder. Relative paths are interpreted from the current directory. Redirection with `>` and `>>` behaves differently: one replaces contents and the other appends. A package manager provides a consistent way to manage software packages.

## 5. Difficulties faced
[FILL IN: Describe any errors, confusing steps or unexpected results. If none, write "No major difficulties".]

## 6. How I resolved them
[FILL IN: Explain the steps or help used to resolve each difficulty. If none, write "Not applicable".]

## 7. Evidence / files
- `[ADD OUTPUT OR SCREENSHOT OF SAFE PRACTICE FILES]`
- `[ADD YOUR COMMAND OBSERVATIONS; REDACT PERSONAL PATHS AND USERNAMES]`

## 8. Commit details
- Commit message: `[FILL IN after creating the commit]`
- Pushed to GitHub: `[YES / NO — verify on GitHub]`
- Commit URL or short hash: `[FILL IN]`
