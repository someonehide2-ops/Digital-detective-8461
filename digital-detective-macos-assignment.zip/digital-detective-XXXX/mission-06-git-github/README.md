# Mission 6 — Git and GitHub

## 1. Task / objective
Understand version control, stage and commit changes, create a branch, open a Pull Request and explain the collaboration workflow.

## 2. Work completed
### Task 6.1 — Basic Git workflow

| Git operation | Command | Explanation |
|---|---|---|
| Check repository status | `git status` | Shows changed, staged and untracked files. |
| Stage selected changes | `git add path/to/README.md` | Selects a change to be included in the next commit. |
| Create a commit | `git commit -m "Describe the change"` | Records staged changes in local repository history. |
| View commit history | `git log --oneline` | Shows a compact commit history. |

Staging selects the changes to include in a commit. Committing saves a snapshot of those staged changes in the local Git history. A commit is not automatically pushed to GitHub.

### Task 6.2 — Create and use a branch

Use these commands from the repository root:

```bash
git switch -c update-about
```

Add a `My Learning` section to the root README with two or three things you have genuinely learned. Then:

```bash
git status
git add README.md
git commit -m "Add learning summary to README"
git push -u origin update-about
```

### Task 6.3 — Create a Pull Request

On GitHub, compare `update-about` with `main` and create a Pull Request from `update-about` into `main`. Describe the README change. Review the changed file. Merge only if your instructor asks you to do so.

A branch is a separate line of development that allows changes to be made without immediately changing the main branch. A Pull Request proposes changes from one branch to another so they can be reviewed before merging.

- Pull Request URL: `[FILL IN]`
- Pull Request status: `[OPEN / MERGED / CLOSED — verify]`
- Merge performed only if instructed: `[FILL IN]`

If the Pull Request is merged, update the local main branch:

```bash
git switch main
git pull origin main
```

### Task 6.4 — Git command glossary

| Operation | Command | Meaning |
|---|---|---|
| Initialise repository | `git init` | Starts Git tracking in a folder. |
| Check status | `git status` | Shows the state of working files and staging area. |
| Stage changes | `git add` | Selects changes for the next commit. |
| Commit changes | `git commit` | Records staged changes locally. |
| View history | `git log` | Displays previous commits. |
| Create/list branches | `git branch` | Lists branches; with a name, creates a branch. |
| Switch branches | `git switch` | Changes the current branch. |
| Publish changes | `git push` | Sends local commits to a remote repository. |
| Retrieve remote changes | `git pull` | Fetches and integrates remote changes. |

[FILL IN: Record the branch name, commit hash, Pull Request URL and actual status.]

## 3. Commands / tools used
Git commands listed above; GitHub website for branch comparison and Pull Request creation. Do not include passwords, personal access tokens or other credentials in this repository.

## 4. My understanding
Git tracks project history locally. GitHub hosts repositories online. The working tree contains current file changes, the staging area selects changes for the next commit, and commits record snapshots. Branches and Pull Requests support review and collaboration.

## 5. Difficulties faced
[FILL IN: Describe any errors, confusing steps or unexpected results. If none, write "No major difficulties".]

## 6. How I resolved them
[FILL IN: Explain the steps or help used to resolve each difficulty. If none, write "Not applicable".]

## 7. Evidence / files
- `[ADD PRIVACY-SAFE git status / git log --oneline OUTPUT]`
- `[ADD GITHUB BRANCH AND PULL REQUEST URL OR SCREENSHOT]`

## 8. Commit details
- Commit message: `[FILL IN after creating the commit]`
- Pushed to GitHub: `[YES / NO — verify on GitHub]`
- Commit URL or short hash: `[FILL IN]`
