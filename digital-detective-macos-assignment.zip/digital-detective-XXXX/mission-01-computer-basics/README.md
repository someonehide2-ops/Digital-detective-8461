# Mission 1 — Know your computer

## 1. Task / objective
Explain how a computer receives input, processes information, produces output and stores results. Identify hardware, software and computer-based systems.

## 2. Work completed
### Task 1.1 — IPOS example: typing and saving a document

| Stage | What happens | Hardware / component |
|---|---|---|
| Input | I press keys and use the mouse to enter and edit text. | Keyboard and mouse |
| Processing | The computer interprets the input and updates the document in memory. | CPU and RAM |
| Output | The edited document appears on the display. | Screen / GPU |
| Storage | I save the document so it remains available later. | SSD or other storage |

The input is processed by the computer, shown as output, and saved to storage when I choose Save.

### Task 1.2 — Hardware and software examples

| Item | Hardware or software? | Software type | Purpose |
|---|---|---|---|
| Keyboard | Hardware | Not applicable | Enters text and commands |
| Mouse / trackpad | Hardware | Not applicable | Controls the pointer and selects items |
| Monitor / display | Hardware | Not applicable | Shows visual output |
| SSD | Hardware | Not applicable | Stores files and applications |
| macOS | Software | Operating system | Manages hardware and applications |
| Safari | Software | Application | Browses websites |
| TextEdit | Software | Application | Creates and edits text |
| Activity Monitor | Software | Utility | Observes processes and resource use |

### Task 1.3 — Everyday computer systems

| System | Main purpose | One input | One output |
|---|---|---|---|
| ATM | Provides banking services | Card and PIN | Cash or transaction receipt |
| Traffic signal controller | Controls traffic lights | Vehicle / pedestrian sensor | Traffic light signal |
| Smart TV | Plays digital media | Remote-control button | Picture and sound |

[FILL IN: Add or replace examples with systems you personally see around you.]

## 3. Commands / tools used
No Terminal command is required for the concept tables. Tools: computer, text editor and this Markdown file.

## 4. My understanding
IPOS describes a common flow in a computer system. Hardware is the physical equipment. Software is the set of programs and instructions. Operating-system software manages the computer, application software helps a user complete tasks, and utility software helps maintain or inspect the system.

## 5. Difficulties faced
[FILL IN: Describe any errors, confusing steps or unexpected results. If none, write "No major difficulties".]

## 6. How I resolved them
[FILL IN: Explain the steps or help used to resolve each difficulty. If none, write "Not applicable".]

## 7. Evidence / files
- This README contains the IPOS, hardware/software and everyday-system tables.
- `[OPTIONAL: ADD YOUR OWN PRIVACY-SAFE PHOTOGRAPH OR NOTES]`

## 8. Commit details
- Commit message: `[FILL IN after creating the commit]`
- Pushed to GitHub: `[YES / NO — verify on GitHub]`
- Commit URL or short hash: `[FILL IN]`
