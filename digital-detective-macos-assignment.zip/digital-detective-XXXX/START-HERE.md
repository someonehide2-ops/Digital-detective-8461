# Start here — macOS

1. Rename the project folder and repository from `digital-detective-XXXX` to `digital-detective-<last-four-USN-digits>`.
2. Open Terminal and move into the project folder.
3. Check prerequisites:
   ```bash
   python3 --version
   git --version
   ```
4. Open the root `README.md` and replace the student/repository placeholders you are allowed to publish.
5. Work through missions in order. Perform the practical tasks on your own Mac and fill in the observation/evidence placeholders with what you actually see.
6. Do not publish private account, device or network information.
7. Commit and push each mission separately. Verify the commit is visible on GitHub before moving to the next mission.
8. Create the GitHub Pull Request in Mission 6 and follow your instructor's merge instruction.
9. Complete the Mission 8 checklist and submit your public repository URL using the instructor's form.

## Safe initial Git commands

After creating the public GitHub repository and copying its remote URL, run these from the project folder (replace the URL with your own repository URL):

```bash
git init
git add .
git commit -m "Set up Digital Detective mission structure"
git branch -M main
git remote add origin <YOUR_GITHUB_REPOSITORY_URL>
git push -u origin main
```

Do not share your GitHub password or access token. GitHub authentication should be completed through the normal secure sign-in flow.
