# The Digital Detective — Diwali Independent Learning Assignment

A mission-based exploration of computer fundamentals, macOS Terminal, operating systems, programs, number systems, Git/GitHub and computer networks.

> **Before publishing:** Replace every `[FILL IN]` or `[ADD YOUR ...]` placeholder with your own verified information. Do not publish private information such as your Mac username, device name, serial number, Wi-Fi name, IP address, passwords or access tokens.

## Student and repository details

- Student name: `[FILL IN — only if instructor permits public disclosure]`
- USN: `[DO NOT PUBLISH unless instructor explicitly permits it]`
- Campus / section: `[FILL IN if appropriate]`
- GitHub username: `[FILL IN]`
- Repository name: `digital-detective-XXXX` (replace `XXXX` with the last four digits of your USN)
- Repository URL: `[ADD YOUR PUBLIC GITHUB REPOSITORY URL]`
- Operating system: macOS
- Python version: `[FILL IN after running python3 --version]`
- Git version: `[FILL IN after running git --version]`

## Mission index

| Mission | Topic | Documentation |
|---|---|---|
| 0 | Repository and workspace setup | [Mission 00](mission-00-setup/README.md) |
| 1 | Computer fundamentals and IPOS | [Mission 01](mission-01-computer-basics/README.md) |
| 2 | Terminal and file management | [Mission 02](mission-02-terminal/README.md) |
| 3 | Operating system, processes and permissions | [Mission 03](mission-03-operating-system/README.md) |
| 4 | How programs run | [Mission 04](mission-04-programs/README.md) |
| 5 | Number systems, Python and text encoding | [Mission 05](mission-05-numbers-data/README.md) |
| 6 | Git, GitHub, branches and Pull Requests | [Mission 06](mission-06-git-github/README.md) |
| 7 | Computer networks | [Mission 07](mission-07-networking/README.md) |
| 8 | Final review and submission | [Mission 08](mission-08-final-report/README.md) |

## Topics explored

- Input, processing, output and storage (IPOS)
- Hardware, operating-system software, application software and utility software
- macOS Terminal commands, files, directories, flags and pipes
- Operating-system responsibilities, processes, storage, paths and permissions
- Python execution and compiler/interpreter concepts
- Decimal, binary and hexadecimal number systems
- ASCII, UTF-8 and character encoding
- Git version control, commits, branches and Pull Requests
- LAN, MAN, WAN, DNS, routers, protocols, packet switching and client-server communication

## Run the number converter

From the repository root, run:

```bash
cd mission-05-numbers-data
python3 number_converter.py
```

Enter a positive whole number when prompted. The program displays its binary and hexadecimal representations.

## Learning summary

`[WRITE 4–6 sentences in your own words about what you learned, what practical work you completed, and which topic was most useful or challenging.]`

## Mission completion and commits

Each mission is intended to be completed, documented and committed separately before starting the next mission. The commit details in each mission README are placeholders until the work is actually committed and pushed. Do not claim a push, Pull Request or observation that you have not completed.

## Repository structure

```text
digital-detective-XXXX/
├── README.md
├── mission-00-setup/
│   └── README.md
├── mission-01-computer-basics/
│   └── README.md
├── mission-02-terminal/
│   └── README.md
├── mission-03-operating-system/
│   └── README.md
├── mission-04-programs/
│   ├── README.md
│   └── hello.py
├── mission-05-numbers-data/
│   ├── README.md
│   └── number_converter.py
├── mission-06-git-github/
│   └── README.md
├── mission-07-networking/
│   └── README.md
├── mission-08-final-report/
│   └── README.md
└── evidence/
    └── README.md
```
