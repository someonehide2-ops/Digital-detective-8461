# Mission 3 — Understand the operating system

## 1. Task / objective
Explore the operating system, running processes, storage, paths and file permissions, and describe operating-system responsibilities.

## 2. Work completed
### Task 3.1 — Explore macOS

Use the following commands and record privacy-safe results. Do not publish your account name, device name or other identifying information.

| Information explored | Command | What it tells you | Your observation |
|---|---|---|---|
| Operating-system version | `sw_vers` | macOS product name, version and build | `[FILL IN; redact device-specific details if any]` |
| Current account identity | `whoami` | Prints the current account name | `[DO NOT PUBLISH THE VALUE; write "Checked locally; redacted"]` |
| Available and used storage | `df -h .` | Filesystem space for the current repository location | `[FILL IN general capacity / availability only]` |
| System activity snapshot | `top -l 1` | Brief snapshot of processes and resource activity | `[FILL IN a short summary; omit usernames and sensitive details]` |

### Task 3.2 — Understand processes

A process is an instance of a running program. A process identifier (PID) is a number the operating system uses to distinguish a process.

Open a browser or text editor, then inspect processes with:

```bash
ps -axo pid,comm | head -n 15
```

- What is a process? A running instance of a program.
- What does PID represent? The process identifier assigned by the operating system.
- Two possible examples: a web browser process and a text editor process. `[VERIFY which applications you actually observed.]`

### Task 3.3 — Paths and permissions

An absolute path starts from the filesystem root and identifies a location independently of the current directory. A relative path describes a location from the current working directory.

Examples (replace with your actual repository-relative paths):
- Absolute path: `[REDACTED OR GENERALIZED ABSOLUTE PATH TO YOUR REPOSITORY]`
- Relative path: `mission-03-operating-system/README.md`

View permissions for a file in the repository:

```bash
ls -l mission-03-operating-system/README.md
```

The permission letters are grouped for owner, group and others. `r` means read, `w` means write and `x` means execute. Do not change system permissions for this assignment.

### Task 3.4 — Operating-system responsibilities

| Responsibility | Explanation | Example |
|---|---|---|
| Process management | Starts, schedules and manages running programs. | Sharing CPU time between a browser and editor. |
| Memory management | Allocates and releases RAM for programs. | Giving an application memory while it runs. |
| Device management | Coordinates hardware devices through drivers and system services. | Managing keyboard and printer input/output. |
| File management | Organises files and directories and controls access to them. | Saving a document in a folder. |
| User interface / shell | Lets people interact with the computer through graphical or command-line interfaces. | Finder or Terminal. |
| Security and permissions | Controls access to files, accounts and system resources. | Requiring permission before an app accesses protected data. |

[FILL IN: Add your actual privacy-safe observations from your Mac.]

## 3. Commands / tools used
`sw_vers` displays macOS version information; `whoami` identifies the current account (do not publish its output); `df -h .` reports storage for the current filesystem; `top -l 1` takes a brief activity snapshot; `ps -axo pid,comm` lists process IDs and commands; `head` limits displayed lines; `ls -l` shows file permissions.

## 4. My understanding
The operating system coordinates hardware and provides common services to applications. A process is a running program. Paths identify file locations, and permissions determine which users can read, write or execute files.

## 5. Difficulties faced
[FILL IN: Describe any errors, confusing steps or unexpected results. If none, write "No major difficulties".]

## 6. How I resolved them
[FILL IN: Explain the steps or help used to resolve each difficulty. If none, write "Not applicable".]

## 7. Evidence / files
- `[ADD REDACTED OUTPUT OR NOTES FOR sw_vers, df, top AND ps]`
- `[ADD SAFE ls -l PERMISSION OBSERVATION]`

## 8. Commit details
- Commit message: `[FILL IN after creating the commit]`
- Pushed to GitHub: `[YES / NO — verify on GitHub]`
- Commit URL or short hash: `[FILL IN]`
