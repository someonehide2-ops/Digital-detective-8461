# Mission 0 — Create your GitHub workspace

## 1. Task / objective
Create a public GitHub repository with the required mission folders and a root README. Use the repository name `digital-detective-XXXX`, replacing XXXX with the last four digits of your USN. The local folder and GitHub repository names must match.

## 2. Work completed
- [ ] Create the local project folder and open it in Terminal and a text editor.
- [ ] Create all mission folders and README files.
- [ ] Check Python 3 and Git versions.
- [ ] Create the public GitHub repository with the exact same name.
- [ ] Connect the local repository, push the initial files and verify them online.
- Repository name: `[FILL IN]`
- Python version (`python3 --version`): `[FILL IN]`
- Git version (`git --version`): `[FILL IN]`
- Setup issue and resolution: `[FILL IN]`

## 3. Commands / tools used
| Command / tool | Purpose |
|---|---|
| `python3 --version` | Displays the installed Python 3 version. |
| `git --version` | Displays the installed Git version. |
| `pwd` | Displays the current working directory. |
| `mkdir` | Creates directories. |
| `touch` | Creates empty files on macOS. |
| GitHub website | Creates and hosts the remote repository. |
| Text editor | Creates and edits Markdown files. |

## 4. My understanding
A Git repository is a project whose changes are tracked by Git. Organising the work into mission folders makes each part easier to find, review and commit separately. The remote GitHub repository stores a copy online for sharing and collaboration.

## 5. Difficulties faced
[FILL IN: Describe any errors, confusing steps or unexpected results. If none, write "No major difficulties".]

## 6. How I resolved them
[FILL IN: Explain the steps or help used to resolve each difficulty. If none, write "Not applicable".]

## 7. Evidence / files
- Root `README.md` and mission folder structure.
- `[ADD PRIVACY-SAFE SCREENSHOT OR OUTPUT SHOWING THE REPOSITORY ON GITHUB]`

## 8. Commit details
- Commit message: `[FILL IN after creating the commit]`
- Pushed to GitHub: `[YES / NO — verify on GitHub]`
- Commit URL or short hash: `[FILL IN]`
