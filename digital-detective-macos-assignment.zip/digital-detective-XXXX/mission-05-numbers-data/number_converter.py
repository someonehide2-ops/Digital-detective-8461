"""Convert a positive decimal whole number to binary and hexadecimal."""


def main():
    raw_value = input("Enter a positive decimal whole number: ").strip()

    try:
        number = int(raw_value)
    except ValueError:
        print("Please enter a valid whole number.")
        return

    if number <= 0:
        print("Please enter a positive whole number greater than zero.")
        return

    binary_value = bin(number)[2:]
    hexadecimal_value = hex(number)[2:]

    print(f"Decimal: {number}")
    print(f"Binary: {binary_value}")
    print(f"Hexadecimal: {hexadecimal_value}")


if __name__ == "__main__":
    main()
