# Mission 5 — Numbers and data

## 1. Task / objective
Convert decimal, binary and hexadecimal values, verify results with Python, build a small converter and explain text encoding.

## 2. Work completed
### Task 5.1 — Manual number conversions

| Question | Working and answer |
|---|---|
| Decimal 13 to binary | 13 = 8 + 4 + 1, so bits for 8, 4, 2, 1 are 1, 1, 0, 1: **1101₂**. |
| Decimal 25 to binary | 25 = 16 + 8 + 1, so **11001₂**. |
| Binary 1010 to decimal | 1×8 + 0×4 + 1×2 + 0×1 = **10₁₀**. |
| Binary 1101 to decimal | 1×8 + 1×4 + 0×2 + 1×1 = **13₁₀**. |
| Hexadecimal A to decimal | A represents **10₁₀**. |
| Hexadecimal 1F to decimal | 1×16 + 15 = **31₁₀**. |
| Binary 1111 to hexadecimal | 1111₂ = 15₁₀ = **F₁₆**. |

### Task 5.2 — Verify using Python

Try these expressions in the Python interactive environment (`python3`):

| Conversion | Python expression | Result |
|---|---|---|
| Decimal 13 to binary | `bin(13)` | `'0b1101'` |
| Decimal 25 to binary | `bin(25)` | `'0b11001'` |
| Binary 1010 to decimal | `int('1010', 2)` | `10` |
| Binary 1101 to decimal | `int('1101', 2)` | `13` |
| Decimal 31 to hexadecimal | `hex(31)` | `'0x1f'` |
| Hexadecimal 1F to decimal | `int('1F', 16)` | `31` |

[FILL IN: Record which expressions you personally tested and whether each matched your manual calculation.]

### Task 5.3 — Number converter

The working `number_converter.py` file is included in this folder. Run it from the repository root:

```bash
python3 mission-05-numbers-data/number_converter.py
```

Example test values:

| Test number | Binary output | Hexadecimal output |
|---:|---|---|
| 10 | `1010` | `a` |
| 25 | `11001` | `19` |
| 255 | `11111111` | `ff` |

`bin()` converts an integer to a binary string with a `0b` prefix. `hex()` converts an integer to a hexadecimal string with a `0x` prefix. The program removes these prefixes for a cleaner display.

[FILL IN: Run the program and record your own three test inputs and exact outputs.]

### Task 5.4 — How is text stored?

- ASCII decimal code for uppercase `A`: **65**.
- ASCII decimal code for lowercase `a`: **97**.
- An encoding standard gives computers a consistent way to represent characters as numbers/bytes so text can be stored and interpreted correctly.
- Example of a character outside basic ASCII: **₹** or **é**.

UTF-8 can represent a much wider range of characters than basic ASCII and is compatible with ASCII for the basic character range.

## 3. Commands / tools used
Python interactive shell: `python3`. Functions: `bin(integer)`, `hex(integer)`, `int(text, base)`, `input(prompt)`, `print(value)` and `strip()` for trimming whitespace.

## 4. My understanding
Decimal uses base 10, binary uses base 2 and hexadecimal uses base 16. Each position represents a power of the base. A byte contains eight bits. Text encodings map characters to numeric byte sequences so different systems can store and exchange text consistently.

## 5. Difficulties faced
[FILL IN: Describe any errors, confusing steps or unexpected results. If none, write "No major difficulties".]

## 6. How I resolved them
[FILL IN: Explain the steps or help used to resolve each difficulty. If none, write "Not applicable".]

## 7. Evidence / files
- `number_converter.py`
- `[ADD YOUR MANUAL WORKING AND PYTHON VERIFICATION NOTES]`
- `[ADD THREE REAL PROGRAM TESTS]`

## 8. Commit details
- Commit message: `[FILL IN after creating the commit]`
- Pushed to GitHub: `[YES / NO — verify on GitHub]`
- Commit URL or short hash: `[FILL IN]`
