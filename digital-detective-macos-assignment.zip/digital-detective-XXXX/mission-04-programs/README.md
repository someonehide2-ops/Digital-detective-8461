# Mission 4 — How programs run

## 1. Task / objective
Run a simple Python program and compare how compilers and interpreters translate or execute programs.

## 2. Work completed
### Task 4.1 — Run a Python program

The file `hello.py` is included in this folder. From the repository root, run:

```bash
python3 mission-04-programs/hello.py
```

Expected output:

```text
Hello from Python
```

[FILL IN: Confirm the output you actually saw, or describe the error and how you resolved it.]

### Task 4.2 — Compiler and interpreter comparison

| Point | Compiler | Interpreter |
|---|---|---|
| When translation / execution happens | Translates source code before the resulting program is run. | Carries out instructions at runtime, often while processing the program. |
| Typical output | Often produces object code or an executable form. | Often produces program behaviour directly without a separate native executable. |
| One example | A C compiler such as Clang | A Python interpreter |
| One advantage | Compiled output can run efficiently without recompiling source every time. | Can make testing and interactive execution convenient. |

A compiler translates source code into another form before the program runs. An interpreter executes instructions at runtime. Actual language implementations can combine approaches: Python commonly compiles source to bytecode and then executes that bytecode in its virtual machine, so the distinction is not always absolute.

## 3. Commands / tools used
`python3 mission-04-programs/hello.py` runs the Python 3 program from Terminal. The text editor is used to inspect or edit `hello.py`.

## 4. My understanding
A program is a set of instructions. Python code is saved in a `.py` file and executed by the Python runtime. Compilers and interpreters describe different approaches to translating and executing source code, though real implementations may combine them.

## 5. Difficulties faced
[FILL IN: Describe any errors, confusing steps or unexpected results. If none, write "No major difficulties".]

## 6. How I resolved them
[FILL IN: Explain the steps or help used to resolve each difficulty. If none, write "Not applicable".]

## 7. Evidence / files
- `hello.py`
- `[ADD A PRIVACY-SAFE TERMINAL OUTPUT SCREENSHOT OR TRANSCRIBE THE RESULT]`

## 8. Commit details
- Commit message: `[FILL IN after creating the commit]`
- Pushed to GitHub: `[YES / NO — verify on GitHub]`
- Commit URL or short hash: `[FILL IN]`
