# Evidence folder

Place only privacy-safe screenshots or selected outputs here, grouped by mission if useful.

Before adding evidence, redact:
- macOS account usernames and device names
- Email addresses and personal details
- Serial numbers
- Wi-Fi names and passwords
- Private or local IP addresses
- Access tokens, passwords and credentials

Suggested organisation:

```text
evidence/
├── mission-00-setup/
├── mission-02-terminal/
├── mission-03-operating-system/
├── mission-04-programs/
├── mission-05-numbers-data/
├── mission-06-git-github/
└── mission-07-networking/
```

Do not create or add screenshots that imply a task was completed if it was not actually performed.
